import React from "react";
import { FullTransactionData } from "../types";

interface Props {
  data: FullTransactionData[];
}

function quantile(sorted: number[], q: number): number {
  if (!sorted.length) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  const next = sorted[base + 1] ?? sorted[base];
  return sorted[base] + rest * (next - sorted[base]);
}

const ParisMap: React.FC<Props> = ({ data }) => {
  // stats par zone: count = somme(count) et avgRisk pondéré
  const zoneStats = Array(20)
    .fill(0)
    .map((_, i) => {
      const zoneId = i + 1;
      const items = data.filter((t) => t.zone_paris === zoneId);

      if (items.length === 0) return { count: 0, avgRisk: 0 };

      const totalCount = items.reduce((acc, curr) => acc + (curr.count ?? 1), 0);

      const weightedRiskSum = items.reduce((acc, curr) => {
        const c = curr.count ?? 1;
        const r = curr.risk?.score ?? 0; // ici on attend 0..100 (comme ton tooltip l'affiche)
        return acc + r * c;
      }, 0);

      const avgRisk = totalCount > 0 ? weightedRiskSum / totalCount : 0;

      return { count: totalCount, avgRisk };
    });

  // ✅ Seuils DYNAMIQUES pour avoir du vert / orange / rouge
  // On calcule sur les zones qui ont une activité (count > 0)
  const activeCounts = zoneStats
    .map((z) => z.count)
    .filter((c) => Number.isFinite(c) && c > 0)
    .sort((a, b) => a - b);

  // si très peu de données, fallback safe
  const q33 = activeCounts.length >= 3 ? quantile(activeCounts, 0.33) : 2;
  const q66 = activeCounts.length >= 3 ? quantile(activeCounts, 0.66) : 5;

  // Couleur = selon la fréquence relative (quantiles), glow selon risque
  const getColor = (risk: number, count: number) => {
    if (count === 0) return "bg-slate-800/50 border-slate-800 text-slate-600";

    // ✅ calme / moyen / chaud basés sur la distribution réelle
    if (count <= q33) return "bg-emerald-500/25 border-emerald-500/35 text-emerald-300";
    if (count <= q66) return "bg-amber-500/25 border-amber-500/35 text-amber-300";

    // chaud -> rouge, pulse seulement si avgRisk élevé
    return risk >= 70
      ? "bg-red-500/25 border-red-500/35 text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.25)] animate-pulse"
      : "bg-red-500/20 border-red-500/30 text-red-300 shadow-[0_0_10px_rgba(239,68,68,0.15)]";
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 grid grid-cols-5 gap-2">
        {zoneStats.map((stat, idx) => (
          <div
            key={idx}
            className={`
              relative rounded flex flex-col items-center justify-center border text-[10px] font-mono cursor-help group transition-all duration-300
              ${getColor(stat.avgRisk, stat.count)}
            `}
          >
            <span className="font-bold">{idx + 1}</span>

            {/* petit badge count */}
            {stat.count > 0 && (
              <span className="mt-1 text-[10px] font-bold opacity-90">{stat.count}</span>
            )}

            {/* Tooltip */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-44 bg-slate-800 border border-slate-600 p-3 rounded shadow-xl hidden group-hover:block z-20 text-center pointer-events-none">
              <div className="text-white font-bold mb-1">Paris {idx + 1}</div>
              <div className="text-slate-300 text-[10px]">Signalements: {stat.count}</div>
              {stat.count > 0 && (
                <div className="text-slate-400 text-[10px]">
                  Risque moy: {Math.round(stat.avgRisk)}/100
                </div>
              )}

              {/* ✅ petit debug discret (tu peux supprimer après) */}
              {stat.count > 0 && (
                <div className="text-slate-500 text-[10px] mt-1">
                  seuils: ≤{Math.round(q33)} vert • ≤{Math.round(q66)} orange
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 flex justify-between text-[10px] text-slate-500 font-medium">
        <span>Activité normale</span>
        <span>Signalements fréquents</span>
      </div>
      <div className="h-1 w-full bg-gradient-to-r from-emerald-900/50 via-amber-900/50 to-red-900 rounded-full mt-1"></div>
    </div>
  );
};

export default ParisMap;
